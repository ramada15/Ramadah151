// رمادة - دالة الأسعار (Netlify Function, Node 18+)
// المتغيرات المطلوبة في Netlify: APCA_KEY و APCA_SECRET
const D = "https://data.alpaca.markets/v2/stocks";
const NY = "America/New_York";

const dateET = (d) => new Intl.DateTimeFormat("en-CA", { timeZone: NY }).format(d);

function sessionOf(now) {
  const p = Object.fromEntries(
    new Intl.DateTimeFormat("en-US", { timeZone: NY, hour12: false, weekday: "short", hour: "2-digit", minute: "2-digit" })
      .formatToParts(now).map((x) => [x.type, x.value])
  );
  const m = (+p.hour % 24) * 60 + +p.minute;
  if (p.weekday === "Sat" || p.weekday === "Sun") return "closed";
  if (m >= 240 && m < 570) return "pre";      // 4:00 - 9:30
  if (m >= 570 && m < 960) return "regular";  // 9:30 - 16:00
  if (m >= 960 && m < 1200) return "after";   // 16:00 - 20:00
  return "closed";
}

async function get(url) {
  const r = await fetch(url, {
    headers: { "APCA-API-KEY-ID": process.env.APCA_KEY, "APCA-API-SECRET-KEY": process.env.APCA_SECRET },
  });
  if (!r.ok) throw new Error(`Alpaca ${r.status}: ${(await r.text()).slice(0, 120)}`);
  return r.json();
}

exports.handler = async (event) => {
  try {
    if (!process.env.APCA_KEY || !process.env.APCA_SECRET) throw new Error("APCA_KEY / APCA_SECRET غير مضبوطة في Netlify");
    const syms = [...new Set(((event.queryStringParameters || {}).symbols || "").toUpperCase().split(","))]
      .filter((s) => /^[A-Z.]{1,6}$/.test(s)).slice(0, 30);
    if (!syms.length) throw new Error("لا توجد رموز");

    const now = new Date();
    const ses = sessionOf(now);
    const reg = ses === "regular";
    const today = dateET(now);
    const q = encodeURIComponent(syms.join(","));
    // أثناء الجلسة: IEX لحظي. قبل الافتتاح وبعد الإغلاق: SIP متأخر 15 دقيقة (الحد المسموح في الخطة المجانية)
    const feed = reg ? "iex" : "sip";
    const end = reg ? "" : "&end=" + new Date(now.getTime() - 16 * 60000).toISOString();
    const start = new Date(now.getTime() - 30 * 3600e3).toISOString();

    const [snap, barsRes] = await Promise.all([
      get(`${D}/snapshots?symbols=${q}&feed=iex`),
      get(`${D}/bars?symbols=${q}&timeframe=5Min&start=${start}${end}&feed=${feed}&limit=10000&sort=asc`),
    ]);

    const data = syms.map((sym) => {
      const s = snap[sym];
      if (!s) return null;
      const d = s.dailyBar, pd = s.prevDailyBar;
      // أساس الارتكاز: آخر جلسة مكتملة (أثناء الجلسة نستبعد شمعة اليوم الجارية)
      const base = reg && d && dateET(new Date(d.t)) === today ? pd : d;
      if (!base) return null;

      let b = ((barsRes.bars || {})[sym] || []).filter((x) => new Date(x.t).getTime() + 300000 <= now.getTime());
      if (b.length) {
        const day = dateET(new Date(b[b.length - 1].t));
        b = b.filter((x) => dateET(new Date(x.t)) === day);
      }
      const last = b[b.length - 1];
      const px = reg && s.latestTrade ? s.latestTrade.p : last ? last.c : s.latestTrade && s.latestTrade.p;
      if (px == null) return null;

      // مؤشر الزخم 0-3 (نفس منطق سكربت بايثون)
      const P = (base.h + base.l + base.c) / 3;
      let sc = 0;
      if (last && (last.h < P || last.l > P)) {
        const sg = last.l > P ? 1 : -1, rng = last.h - last.l;
        const body = rng > 0 ? Math.abs(last.c - last.o) / rng : 0;
        const prev = b.slice(-21, -1);
        const pv = prev.length ? prev.reduce((a, x) => a + x.v, 0) / prev.length : 0;
        const tv = b.reduce((a, x) => a + x.v, 0);
        const vw = tv ? b.reduce((a, x) => a + ((x.h + x.l + x.c) / 3) * x.v, 0) / tv : last.c;
        const sma = b.slice(-20).reduce((a, x) => a + x.c, 0) / Math.min(20, b.length);
        sc = (sg * (last.c - last.o) > 0 && body >= 0.6 ? 1 : 0) + (pv > 0 && last.v / pv >= 1.5 ? 1 : 0) +
             (sg * (last.c - vw) > 0 && sg * (last.c - sma) > 0 ? 1 : 0);
      }
      return { sym, px, chg: ((px - base.c) / base.c) * 100, H: base.h, L: base.l, C: base.c,
               ch: last ? last.h : null, cl: last ? last.l : null, sc, t: last ? last.t : null };
    }).filter(Boolean);

    return {
      statusCode: 200,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
      body: JSON.stringify({ session: ses, delayed: !reg, data }),
    };
  } catch (e) {
    return { statusCode: 502, headers: { "content-type": "application/json" }, body: JSON.stringify({ error: String(e.message).slice(0, 200) }) };
  }
};
